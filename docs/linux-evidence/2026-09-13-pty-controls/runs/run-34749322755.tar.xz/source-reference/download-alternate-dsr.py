from pathlib import Path,PurePosixPath
import hashlib,json,subprocess,zipfile,io,stat,sys
run=sys.argv[1];expected_harness=sys.argv[2];repo='guicybercode/kokuban.rs'
gh=lambda *args:subprocess.check_output(['gh',*args])
run_meta=gh('run','view',run,'--repo',repo,'--json','databaseId,status,conclusion,headSha,url,jobs,createdAt,updatedAt,workflowName')
run_json=json.loads(run_meta);assert run_json['status']=='completed' and run_json['conclusion']=='success' and run_json['headSha']==expected_harness
base=Path('/private/tmp/kokuban-perf-20260913/root-evidence')/f'run-{run}';base.mkdir(exist_ok=False)
meta=gh('api',f'repos/{repo}/actions/runs/{run}/artifacts');(base/'github-artifacts.json').write_bytes(meta)
artifacts=json.loads(meta)['artifacts'];assert len(artifacts)==1;a=artifacts[0]
archive=gh('api',f'repos/{repo}/actions/artifacts/{a["id"]}/zip');digest=hashlib.sha256(archive).hexdigest();assert digest==a['digest'].removeprefix('sha256:')
(base/'artifact.zip').write_bytes(archive)
root=base/a['name'];root.mkdir();files={}
with zipfile.ZipFile(io.BytesIO(archive)) as z:
 for entry in z.infolist():
  path=PurePosixPath(entry.filename);assert not path.is_absolute() and '..' not in path.parts and not stat.S_ISLNK(entry.external_attr>>16)
  if entry.is_dir():continue
  assert entry.filename not in files
  data=z.read(entry);target=root/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  files[entry.filename]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(base/'download-integrity.json').write_text(json.dumps({'status':'PASS','artifact_id':a['id'],'zip_bytes':len(archive),'zip_sha256':digest,'api_digest_verified':True,'files':files},indent=2)+'\n')
(base/'github-run.json').write_bytes(run_meta)
(base/'github-run.log').write_bytes(gh('run','view',run,'--repo',repo,'--log'))
source=base/'source-reference';source.mkdir()
for file in ['.github/workflows/linux-paired-performance.yml','scripts/compare-kokuban-revisions.py','scripts/compare-terminal-performance.py','scripts/linux-resource-smoke.py']:
 (source/Path(file).name).write_bytes(subprocess.check_output(['git','show',f'{expected_harness}:{file}'],cwd='/Users/eguimacs/kokuban.rs'))
note={'run_id':int(run),'related_run_ids':[34749322755,34749492893],'source':'Maintainer instruction in this work session.','note':'Run 34749322755 was created despite HTTP 500 and delayed run listing. Run 34749492893 was an unplanned repeat submitted before the earlier run was discovered. Preserve and report both separately; no result selection or pooling.'}
(base/'scheduling-note.json').write_text(json.dumps(note,indent=2)+'\n')
print('DOWNLOAD PASS',run,a['id'],len(files),'files',len(archive),'ZIP bytes',digest)
